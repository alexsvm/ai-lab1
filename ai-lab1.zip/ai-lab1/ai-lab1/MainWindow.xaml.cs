﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.Immutable;
using System.Threading;



namespace ai_lab1
{

    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        const int StateSize = 19;

        enum Item { Simple = 0, Red = 1, Blue = 2}; // Тип кружочка
        Item NextItemValue(Item item)
        {
            var items = Enum.GetValues(typeof(Item));
            int old_idx = Array.IndexOf(items, item);
            if (old_idx == (items.Length - 1))
                return (Item)0;
            else
                return (Item)(old_idx + 1);
        }
        enum Action: int { a0, a1, a2, a3, a4, a5, a6 , none}; // Возможные ходы - повороты вокруг 0..6 кружка

        // chains - цепочка кружков для поворота
        ImmutableArray<ImmutableArray<int>> chains = ImmutableArray.Create(new ImmutableArray<int>[] {
            ImmutableArray.Create( new int[] { 1, 2, 3, 4, 5, 6 } ),
            ImmutableArray.Create( new int[] { 7, 8, 2, 0, 6, 18 } ),
            ImmutableArray.Create( new int[] { 8, 9, 10, 3, 0, 1 } ),
            ImmutableArray.Create( new int[] { 2, 10, 11, 12, 4, 0 } ),
            ImmutableArray.Create( new int[] { 0, 3, 12, 13, 14, 5 } ),
            ImmutableArray.Create( new int[] { 6, 0, 4, 14, 15, 16 } ),
            ImmutableArray.Create( new int[] { 18, 1, 0, 5, 16, 17 } )
        });

        //int[,] chains = new int[7, 6] { { 1, 2, 3, 4, 5 , 6},
        //    { 7, 8, 2, 0, 6, 18}, { 8, 9, 10, 3, 0, 1 }, { 2, 10, 11, 12, 4, 0 }, 
        //    { 6, 0, 4, 14, 15, 16 }, { 6, 0, 4, 14, 15, 16 }, { 18, 1, 0, 5, 16, 17 }
        //};

        // Item[position] - состояние кружочка в i-позиции
        // Item[] - полное состояние игры
        Item[] state0 = new Item[StateSize] { Item.Simple,
            Item.Simple, Item.Simple, Item.Simple, Item.Simple, Item.Simple, Item.Simple,
            Item.Simple, Item.Simple, Item.Red, Item.Red,    Item.Simple, Item.Simple,
            Item.Simple, Item.Simple, Item.Simple, Item.Simple, Item.Simple, Item.Simple };
        //
        Item[] state_target = new Item[StateSize] { Item.Simple,
            Item.Simple, Item.Simple, Item.Simple, Item.Simple, Item.Simple, Item.Simple,
            Item.Simple, Item.Simple, Item.Simple, Item.Simple, Item.Simple, Item.Simple,
            Item.Simple, Item.Simple, Item.Red, Item.Red, Item.Simple, Item.Simple };
        //
        Button[] buttons_main = new Button[StateSize];
        Button[] buttons_target = new Button[StateSize];
        //

        // ==========================================================================================================
        public MainWindow()
        {
            InitializeComponent();
            // Привязка визуальных компонентов в массиив:
            for (int i = 0; i < StateSize; i++)
            {
                Button btn_main = (Button)CanvasMain.FindName("btn_" + i);
                if (btn_main != null)
                {
                    buttons_main[i] = btn_main;
                    btn_main.Click += ButtonZ_Click;
                    btn_main.Tag = i;
                }
                Button btn_target = (Button)CanvasTarget.FindName("btn_" + (i + 100));
                if (btn_target != null)
                {
                    buttons_target[i] = btn_target;
                    buttons_target[i].Click += ButtonTarget_Click;
                    btn_target.Tag = i;
                }
            }

            DrawState(state0);
            DrawTargetState(state_target);
        }

        /// <summary>
        /// Функция возвращет количество шагов, необходимое для перемещения из a в b
        /// </summary>
        /// <param name="a">Точка a</param>
        /// <param name="b">Точка b</param>
        /// <returns></returns>
        private int GetDistance(int a, int b)
        {
            if (a < 0 || b < 0 || a > 18 || b > 18)
                return -1;
            if (a == b) return 0; // Если точки совпадают, то 0
            if (a == 0) // из центра
            {
                if (b <= 6) return 1; // Из центра в центральное кольцо можно попасть за один ход
                if (b > 6) return b % 2 + 2;  // Из центра на внешнее кольцо за 2 хода в четное или за 3 в нечетное
            }
            if (a <= 6) // из центрального кольца
            {
                if (b == 0) return 1; // В центр за один ход
                if (b <= 6) return (b - a) == 1 || (b == 1 && a == 6)? 1 : 2; // Один ход, если точка следующая по кругу или два хода церез центр
                if (b == 7) return GetDistance(a, 6) + 2;
                if (b > 7) return GetDistance(a, (b - 6) / 2) + 1 + b % 2;
            }
            if (a <= 16)
            {
                if (b == 0) return a % 2 + 2; // Из периферии за два хода, если чет или за три, если нечет
                if ((b - a) <= 2 && b > a) return b - a; // // Один-два хода, если точка следующая по кругу
                return GetDistance((a - 6) / 2 + 1 + a % 2, b) + 1 + a % 2;
            }
            if (a == 18 && b == 7) return 1; // Особый случай
            if (a <= 18)
            {
                if ((b - a) <= 2 && b > a) return b - a; // // Один-два хода, если точка следующая по кругу
                return GetDistance(1, b) + 1 + a % 2; // Особый случай
            }
            return -1;
        }
        //

        /// <summary>
        /// Функция проверки эквивалентности двух состояний
        /// </summary>
        /// <param name="state1">Первое состояние для оценки</param>
        /// <param name="state2">Второе состояние для оценки</param>
        /// <returns></returns>
        private bool StatesEquals(Item[] state1, Item[] state2)
        {
            if (state1.Length != state2.Length)
                return false;
            for (int i = 0; i < state1.Length; i++)
                if (state1[i] != state2[i])
                    return false;
            return true;
        }

        /// <summary>
        /// Эвристическая функция 1
        /// Оценка по количеству кружков соответсвующего типа в НЕцелевом состоянии
        /// </summary>
        /// <param name="state">Исходное расстояние для оценки</param>
        /// <param name="target">Целевое состояние</param>
        /// <returns></returns>
        private int HF_simple(Item[] state, Item[] target)
        {
            var target_list = new Dictionary<int, Item>();
            for (int i = 0; i < target.Length; i++) target_list[i] = target[i];
            int res = 0;
            for (int i = 0; i < state.Length; i++)
            {
                if (state[i] == target_list[i])
                {
                    res++;
                    target_list.Remove(i);
                }
            }
            return 19 - res;
        }

       
        /// <summary>
        /// Функция возвращает массив минимальных расстояний от точек до их целевых позиций
        /// </summary>
        /// <param name="state">Исходное расстояние для оценки</param>
        /// <param name="target">Целевое состояние</param>
        /// <returns></returns>
        private int[] Distances(Item[] state, Item[] target)
        {
            int[] res = new int[state.Length];

            var target_list = new Dictionary<int, Item>(target.Length);
            for (int i = 0; i < state.Length; i++) target_list.Add(i, target[i]);

            for (int i = 0; i < state.Length; i++) // Цикл по всем точкам состояния
            {
                int min_i = 99;
                int min_dist = 99;
                foreach (var t in target_list) // Пробегаемся по всем точкам целевого состояния
                {
                    if (state[i] == t.Value) // Если нашли узел с таким же типом
                    {
                        int dist = GetDistance(i, t.Key); // то берем расстояние до него
                        if (dist <= min_dist) // и если оно меньше мин, то он текущий минимум
                        {
                            min_dist = dist;
                            min_i = t.Key;
                        }
                    }
                }
                if (min_i != 99) // Если мы нашли точку с мин расстоянием
                {
                    res[i] = min_dist; // то к результату добавляем это мин. расстояние
                    target_list.Remove(min_i); // и удялем эту точку из цлевого списка
                }
            }
            return res;
        }

        /// <summary>
        /// Функция возвращает сумму минимальных расстояний от точек до их целевых позиций
        /// </summary>
        /// <param name="state"></param>
        /// <param name="target"></param>
        /// <returns></returns>
        private int Distance(Item[] state, Item[] target)
        {
            int res = 0;
            var distances = Distances(state, target);
            foreach (var d in distances) res += d;
            return res;
        }

        /// <summary>
        /// Функция возвращает новое состояние полученное из начального initialState при помощи действия action,
        /// т.е. поворота вокруг точки Action.x
        /// </summary>
        /// <param name="initialState"></param>
        /// <param name="action"></param>
        /// <returns></returns>
        private Item[] NextState(Item[] initialState, Action action)
        {
            Item[] finalState = new Item[initialState.Length]; // Создаем новое состояние
            Array.Copy(initialState, finalState, initialState.Length); // Копируем в него начальное
            Item buffer = finalState[chains[(int)action][5]]; // Состояние 5-го итема запоминаем
            for (int i = 5; i > 0; i--) // сдвигаем все значения от 1-го до 5-го
                finalState[chains[(int)action][i]] = finalState[chains[(int)action][i-1]];
            finalState[chains[(int)action][0]] = buffer; // в 0-й записываем сохраненное значение
            return finalState;
        }

        // ==========================================================================================================
        private void Log(string msg) { log.Text += msg + Environment.NewLine; }

        // ==========================================================================================================
        private void LogState(Item[] state)
        {
            for (int i = 0; i < state.Length; i++)
                log.Text += i + "=" + state[i] + " ";
            log.Text += Environment.NewLine;
        }


        // ==========================================================================================================
        private void DrawState(Item[] state)
        {
            // На входе - регион отображения или ?
            for (int i = 0; i < state.Length; i++)
            {
                if (state[i] == Item.Simple)
                    buttons_main[i].Template = (ControlTemplate)Application.Current.Resources["ButtonTemplate0"];
                if (state[i] == Item.Red)
                    buttons_main[i].Template = (ControlTemplate)Application.Current.Resources["ButtonTemplate1"];
                if (state[i] == Item.Blue)
                    buttons_main[i].Template = (ControlTemplate)Application.Current.Resources["ButtonTemplate2"];
            }
            // Отобразим метрики:
            var dist = Distance(state, state_target);
            lblMetric.Content = $"Расстояние до целевого состояние = {dist}, HFsimple = {HF_simple(state, state_target)}";
        }

        // ==========================================================================================================
        private void DrawTargetState(Item[] state)
        {
            // На входе - регион отображения или ?
            for (int i = 0; i < state.Length; i++)
            {
                if (state[i] == Item.Simple)
                    buttons_target[i].Template = (ControlTemplate)Application.Current.Resources["ButtonTemplate0"];
                if (state[i] == Item.Red)
                    buttons_target[i].Template = (ControlTemplate)Application.Current.Resources["ButtonTemplate1"];
                if (state[i] == Item.Blue)
                    buttons_target[i].Template = (ControlTemplate)Application.Current.Resources["ButtonTemplate2"];
            }
        }

        /// <summary>
        /// Класс узла графа решений
        /// </summary>
        class Node : IEquatable<Node>
        {
            private Item[] _state;
            private Node _parent;
            private Action _action;
            private int _steps;

            public Item[] state { get => _state; } // Состояние, соответсвующее этому узлу
            public Node parent { get => _parent; } // Родительский узел 
            public Action action { get => _action; } // Шаг игры, который привел от родительского узла к текущему
            public int steps { get => _steps; } // Количество шагов от начала до этого узла

            public Node(Node ParentNode, Item[] State, Action Action, ImmutableArray<ImmutableArray<int>> chains)
            {
                _action = Action;
                _parent = ParentNode;
                if (_parent != null)
                {
                    _steps = ParentNode.steps + 1;
                    _state = new Item[_parent._state.Length]; // Создаем новое состояние
                    Array.Copy(_parent._state, _state, _parent._state.Length); // Копируем в него начальное
                    Item buffer = _state[chains[(int)action][5]]; // Состояние 5-го итема запоминаем
                    for (int i = 5; i > 0; i--) // сдвигаем все значения от 1-го до 5-го
                        _state[chains[(int)action][i]] = _state[chains[(int)action][i - 1]];
                    _state[chains[(int)action][0]] = buffer; // в 0-й записываем сохраненное значение
                }
                else
                {
                    _state = State;
                    _steps = 0;
                }
            }

            private bool StatesEquals(Item[] state1, Item[] state2)
            {
                if (state1.Length != state2.Length)
                    return false;
                for (int i = 0; i < state1.Length; i++)
                    if (state1[i] != state2[i])
                        return false;
                return true;
            }

            public override bool Equals(object obj)
            {
                if (obj == null) return false;
                Node objAsNode = obj as Node;
                if (objAsNode == null) return false;
                else return Equals(objAsNode);
            }

            public bool Equals(Node other)
            {
                if (other == null) return false;
                return StatesEquals(this._state, other._state);
            }
        }
        // ==========================================================================================================

        // ==========================================================================================================
        /// <summary>
        /// Функция поиска решения в ширину
        /// </summary>
        /// <param name="start_state"></param>
        /// <returns></returns>
        private Node BFSsearch(Item[] start, Item[] target)
        {
            Queue<Node> Olist = new Queue<Node>(); // Список открытых вершин
            Queue<Node> Clist = new Queue<Node>(); // Список закрытых вершин
            var xNode = new Node(null, start, Action.none, chains); // Вершина с начальным состоянием
            Olist.Enqueue(xNode); // Поместили в список начальное состояние

            while (Olist.Count > 0)
            {
                xNode = Olist.Dequeue();
                if (StatesEquals(xNode.state, target)) return xNode; // Если текущее состояние совпадает с целью, то все, на выход!
                Clist.Enqueue(xNode); // Помещаем текущйю вершину в закрытый список
                // Раскрываем текущую вершину:                                      
                for (int i = 0; i < 7; i++)
                {
                    var iNode = new Node(xNode, null, (Action)i, chains); // Вершина i кандидат
                    if (!StatesEquals(xNode.state, iNode.state)) // Если новое состояние отличается от текущего, то
                        if (!Olist.Contains(iNode) && !Clist.Contains(iNode)) // Если кандидата нет в закрытом и открытом списке, то
                            Olist.Enqueue(iNode); // помещяем кандидата в открытый список
                }
            }
            // Если мы здесь, то решения нет:
            return null;
        }

        // ==========================================================================================================
        /// <summary>
        /// Функция поиска решения в глубину
        /// </summary>
        /// <param name="start_state"></param>
        /// <returns></returns>
        private Node DFSsearch(Item[] start, Item[] target)
        {
            Stack<Node> Olist = new Stack<Node>(); // Список открытых вершин
            Stack<Node> Clist = new Stack<Node>(); // Список закрытых вершин
            var xNode = new Node(null, start, Action.none, chains); // Вершина с начальным состоянием
            Olist.Push(xNode); // Поместили в список начальное состояние

            while (Olist.Count > 0)
            {
                xNode = Olist.Pop();
                if (StatesEquals(xNode.state, target)) return xNode; // Если текущее состояние совпадает с целью, то все, на выход!
                Clist.Push(xNode); // Помещаем текущйю вершину в закрытый список
                // Раскрываем текущую вершину:                                      
                for (int i = 0; i < 7; i++)
                {
                    var iNode = new Node(xNode, null, (Action)i, chains); // Вершина i кандидат
                    if (!StatesEquals(xNode.state, iNode.state)) // Если новое состояние отличается от текущего, то
                        if (!Olist.Contains(iNode) && !Clist.Contains(iNode)) // Если кандидата нет в закрытом и открытом списке, то
                            Olist.Push(iNode); // помещяем кандидата в открытый список
                }
            }
            // Если мы здесь, то решения нет:
            return null;
        }

        private Node DFSsearch_A(Item[] start, Item[] target)
        {
            Stack<Node> Olist = new Stack<Node>(); // Список открытых вершин
            Stack<Node> Clist = new Stack<Node>(); // Список закрытых вершин
            var xNode = new Node(null, start, Action.none, chains); // Вершина с начальным состоянием
            Olist.Push(xNode); // Поместили в список начальное состояние

            while (Olist.Count > 0)
            {
                xNode = Olist.Pop();
                if (StatesEquals(xNode.state, target)) return xNode; // Если текущее состояние совпадает с целью, то все, на выход!
                Clist.Push(xNode); // Помещаем текущйю вершину в закрытый список
                // Раскрываем текущую вершину:                                      
                var candidate = new List<Node>();
                for (int i = 0; i < 7; i++)
                {
                    var iNode = new Node(xNode, null, (Action)i, chains); // Вершина i кандидат
                    if (!StatesEquals(xNode.state, iNode.state)) // Если новое состояние отличается от текущего, то
                        if (!Olist.Contains(iNode) && !Clist.Contains(iNode)) // Если кандидата нет в закрытом и открытом списке, то
                            candidate.Add(iNode);
                }
                // Сортируем список кандидатов
                candidate.Sort(delegate (Node x, Node y)
                {
                    //int distA = Distance(x.state, target);
                    //int distB = Distance(y.state, target);
                    int distA = HF_simple(x.state, target);
                    int distB = HF_simple(y.state, target);
                    if (distA == distB) return 0;
                    if (distA > distB)
                        return 1;
                    else
                        return -1;
                });
                foreach (var item in candidate)
                    Olist.Push(item); // помещяем кандидата в открытый список
                candidate.Clear();
            }
            // Если мы здесь, то решения нет:
            return null;
        }

        private Node DFSsearch_AStar_plus(Item[] start, Item[] target)
        {
            Stack<Node> Olist = new Stack<Node>(); // Список открытых вершин
            Stack<Node> Clist = new Stack<Node>(); // Список закрытых вершин
            var xNode = new Node(null, start, Action.none, chains); // Вершина с начальным состоянием
            Olist.Push(xNode); // Поместили в список начальное состояние

            while (Olist.Count > 0)
            {
                xNode = Olist.Pop();
                if (StatesEquals(xNode.state, target)) return xNode; // Если текущее состояние совпадает с целью, то все, на выход!
                Clist.Push(xNode); // Помещаем текущйю вершину в закрытый список
                // Раскрываем текущую вершину:                                      
                var candidate = new List<Node>();
                for (int i = 0; i < 7; i++)
                {
                    var iNode = new Node(xNode, null, (Action)i, chains); // Вершина i кандидат
                    if (!StatesEquals(xNode.state, iNode.state)) // Если новое состояние отличается от текущего, то
                        if (!Olist.Contains(iNode) && !Clist.Contains(iNode)) // Если кандидата нет в закрытом и открытом списке, то
                            candidate.Add(iNode);
                }
                // Сортируем список кандидатов
                candidate.Sort(delegate (Node x, Node y)
                {
                    int distA = Distance(x.state, target) + HF_simple(x.state, target);
                    int distB = Distance(y.state, target) + HF_simple(y.state, target);
                    if (distA == distB) return 0;
                    if (distA < distB)
                        return 1;
                    else
                        return -1;
                });
                foreach (var item in candidate)
                    Olist.Push(item); // помещяем кандидата в открытый список
                candidate.Clear();
            }
            // Если мы здесь, то решения нет:
            return null;
        }

        /// <summary>
        /// Анимируем маршрут!!
        /// </summary>
        /// <param name="state"></param>
        /// <param name="actions"></param>
        private async void AnimateActions(Item[] state, List<Action> actions)
        {
            DrawState(state);
            foreach (var a in actions)
            {
                // pause
                //Thread.Sleep(2000);
                await Task.Delay(1000);
                state = NextState(state, a);
                DrawState(state);
            }
        }

        // ==========================================================================================================
        // ==========================================================================================================
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Ellipse eee = (Ellipse)btn0.Template.FindName("buttonSurface", btn0);
            eee.Fill = Brushes.Black;
            btnONE.Content = chains[0][2];
            LogState(state0);
            LogState(NextState(state0, Action.a2));
            DrawState(state0);
            Log("==== distance: ====");
            //Log($"{HF_dy_distance(state0, state_target)}");
            var dists = Distances(state0, state_target);
            for (int i =0; i < dists.Length; i++)
            {
                Log($"dist[{i}]={dists[i]}");
            }
        }

        private void ButtonZ_Click(object sender, RoutedEventArgs e)
        {
            if (sender.GetType().Name == "Button")
            {
                Button btn = (Button)sender;
                if (Int32.Parse(btn.Tag.ToString()) > 6) return;
                Action action = (Action)Int32.Parse(btn.Tag.ToString());
                state0 = NextState(state0, action);
                Log(action.ToString());
                DrawState(state0);
                if (StatesEquals(state0, state_target))
                    Log("VICTORY!!!!");
            }
        }

        private void ButtonTarget_Click(object sender, RoutedEventArgs e)
        {
            if (sender.GetType().Name == "Button")
            {
                Button btn = (Button)sender;
                //if (Int32.Parse(btn.Tag.ToString()) > 6) return;
                //Action action = (Action)Int32.Parse(btn.Tag.ToString());
                //state_target = NextState(state_target, action);
                int btn_idx = Int32.Parse(btn.Tag.ToString());
                state_target[btn_idx] = NextItemValue(state_target[btn_idx]);
                DrawTargetState(state_target);
            }
        }

        private void btnSearch1_Click(object sender, RoutedEventArgs e)
        {
            Node node = BFSsearch(state0, state_target);
            if (node != null)
            {
                Log("===============================");
                Log("Решение найдено:");
                var actions = new List<Action>();
                var iNode = node;
                while (iNode.parent != null)
                {
                    actions.Add(iNode.action);
                    iNode = iNode.parent;
                }
                Log(String.Format("Количество шагов: {0}", actions.Count));
                actions.Reverse();
                string s = "";
                foreach (var a in actions)
                    s += $"{a.ToString()} ";
                Log(s);
                Log("===============================");
                if (chkAnimate.IsChecked ?? false)
                {
                    AnimateActions(state0, actions);
                }
            }
        }

        private void btnSearch2_Click(object sender, RoutedEventArgs e)
        {
            Node node = DFSsearch(state0, state_target);
            if (node != null)
            {
                Log("===============================");
                Log("Решение найдено:");
                var actions = new List<Action>();
                var iNode = node;
                while (iNode.parent != null)
                {
                    actions.Add(iNode.action);
                    iNode = iNode.parent;
                }
                Log(String.Format("Количество шагов: {0}", actions.Count));
                actions.Reverse();
                string s = "";
                foreach (var a in actions)
                    s += $"{a.ToString()} ";
                Log(s);
                Log("===============================");
                if (chkAnimate.IsChecked ?? false)
                {
                    AnimateActions(state0, actions);
                }
            }
        }

        private void slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            int a = Convert.ToInt32(sliderA.Value);
            int b = Convert.ToInt32(sliderB.Value);
            int dist = GetDistance(a, b);
            lblA.Content = a.ToString();
            lblB.Content = b.ToString();
            lblDistance.Content = $"Distance between [{a}] and [{b}] = {dist}";
        }

        private void btnRndState0_Click(object sender, RoutedEventArgs e)
        {
            Array.Copy(state_target, state0, state_target.Length);
            Random rand = new Random();
            for (int i = state0.Length - 1; i >= 1; i--)
            {
                int j = rand.Next(i + 1);
                var tmp = state0[j];
                state0[j] = state0[i];
                state0[i] = tmp;
            }
            DrawState(state0);
        }

        private void btnDFSwithHF1_Click(object sender, RoutedEventArgs e)
        {
            Node node = DFSsearch_A(state0, state_target);
            if (node != null)
            {
                Log("===============================");
                Log("Решение найдено:");
                var actions = new List<Action>();
                var iNode = node;
                while (iNode.parent != null)
                {
                    actions.Add(iNode.action);
                    iNode = iNode.parent;
                }
                Log(String.Format("Количество шагов: {0}", actions.Count));
                actions.Reverse();
                string s = "";
                foreach (var a in actions)
                    s += $"{a.ToString()} ";
                Log(s);
                Log("===============================");
                if (chkAnimate.IsChecked ?? false)
                {
                    AnimateActions(state0, actions);
                }
            }
        }

        private void btnClearLog_Click(object sender, RoutedEventArgs e)
        {
            log.Text = "";
        }

        private void btnDFSwithHF2_Click(object sender, RoutedEventArgs e)
        {
            Node node = DFSsearch_AStar_plus(state0, state_target);
            if (node != null)
            {
                Log("===============================");
                Log("Решение найдено:");
                var actions = new List<Action>();
                var iNode = node;
                while (iNode.parent != null)
                {
                    actions.Add(iNode.action);
                    iNode = iNode.parent;
                }
                Log(String.Format("Количество шагов: {0}", actions.Count));
                actions.Reverse();
                string s = "";
                foreach (var a in actions)
                    s += $"{a.ToString()} ";
                Log(s);
                Log("===============================");
                if (chkAnimate.IsChecked ?? false)
                {
                    AnimateActions(state0, actions);
                }
            }
        }
    }
}
